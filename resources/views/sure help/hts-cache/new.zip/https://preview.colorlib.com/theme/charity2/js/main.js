<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>416 Requested Range Not Satisfiable</title>
<script nonce="2d772437-ad3f-41bf-bc39-90b157a34962">(function(w,d){!function(cO,cP,cQ,cR){cO[cQ]=cO[cQ]||{};cO[cQ].executed=[];cO.zaraz={deferred:[],listeners:[]};cO.zaraz.q=[];cO.zaraz._f=function(cS){return function(){var cT=Array.prototype.slice.call(arguments);cO.zaraz.q.push({m:cS,a:cT})}};for(const cU of["track","set","debug"])cO.zaraz[cU]=cO.zaraz._f(cU);cO.zaraz.init=()=>{var cV=cP.getElementsByTagName(cR)[0],cW=cP.createElement(cR),cX=cP.getElementsByTagName("title")[0];cX&&(cO[cQ].t=cP.getElementsByTagName("title")[0].text);cO[cQ].x=Math.random();cO[cQ].w=cO.screen.width;cO[cQ].h=cO.screen.height;cO[cQ].j=cO.innerHeight;cO[cQ].e=cO.innerWidth;cO[cQ].l=cO.location.href;cO[cQ].r=cP.referrer;cO[cQ].k=cO.screen.colorDepth;cO[cQ].n=cP.characterSet;cO[cQ].o=(new Date).getTimezoneOffset();if(cO.dataLayer)for(const da of Object.entries(Object.entries(dataLayer).reduce(((db,dc)=>({...db[1],...dc[1]})))))zaraz.set(da[0],da[1],{scope:"page"});cO[cQ].q=[];for(;cO.zaraz.q.length;){const dd=cO.zaraz.q.shift();cO[cQ].q.push(dd)}cW.defer=!0;for(const de of[localStorage,sessionStorage])Object.keys(de||{}).filter((dg=>dg.startsWith("_zaraz_"))).forEach((df=>{try{cO[cQ]["z_"+df.slice(7)]=JSON.parse(de.getItem(df))}catch{cO[cQ]["z_"+df.slice(7)]=de.getItem(df)}}));cW.referrerPolicy="origin";cW.src="/cdn-cgi/zaraz/s.js?z="+btoa(encodeURIComponent(JSON.stringify(cO[cQ])));cV.parentNode.insertBefore(cW,cV)};["complete","interactive"].includes(cP.readyState)?zaraz.init():cO.addEventListener("DOMContentLoaded",zaraz.init)}(w,d,"zarazData","script");})(window,document);</script></head><body>
<h1>Requested Range Not Satisfiable</h1>
<p>None of the range-specifier values in the Range
request-header field overlap the current extent
of the selected resource.</p>
<hr>
<address>Apache/2.4.41 (Ubuntu) Server at preview.colorlib.com Port 443</address>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v2b4487d741ca48dcbadcaf954e159fc61680799950996" integrity="sha512-D/jdE0CypeVxFadTejKGTzmwyV10c1pxZk/AqjJuZbaJwGMyNHY3q/mTPWqMUnFACfCTunhZUVcd4cV78dK1pQ==" data-cf-beacon='{"rayId":"7b8b6f902d22dd70","version":"2023.3.0","b":1,"token":"cd0b4b3a733644fc843ef0b185f98241","si":100}' crossorigin="anonymous"></script>
</body></html>
